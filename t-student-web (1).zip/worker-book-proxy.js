// أضف هذا إلى كود الـ Worker عندك.
// 1) في بداية دالة fetch:  if (new URL(request.url).pathname === "/book") return bookProxy(request);
// 2) أضف اسم موقع ملازمنا الحقيقي إلى القائمة أدناه.
const BOOK_HOSTS = ["edumedia-depot.gei.de", "derasaty.net", "mlazemna.com"];
async function bookProxy(request) {
  let t;
  try { t = new URL(new URL(request.url).searchParams.get("url")); } catch { return new Response("bad url", { status: 400 }); }
  if (!BOOK_HOSTS.some(h => t.hostname === h || t.hostname.endsWith("." + h))) return new Response("blocked", { status: 403 });
  const r = await fetch(t, { redirect: "follow", headers: { "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36", "Referer": t.origin + "/" } });
  let r2 = r;
  if ((r.headers.get("content-type") || "").includes("text/html")) {
    const m = (await r.text()).match(/href=["']([^"']+\.pdf[^"']*)["']/i);
    if (!m) return new Response("no pdf link", { status: 422, headers: { "Access-Control-Allow-Origin": "*" } });
    const u2 = new URL(m[1], t);
    if (u2.protocol !== "https:" && u2.protocol !== "http:") return new Response("bad", { status: 400 });
    r2 = await fetch(u2, { redirect: "follow", headers: { "User-Agent": "Mozilla/5.0", "Referer": t.origin + "/" } });
  }
  const h = new Headers(r2.headers);
  h.set("Access-Control-Allow-Origin", "*");
  return new Response(r2.body, { status: r2.status, headers: h });
}
